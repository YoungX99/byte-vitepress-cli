module.exports = {
  title: "Byte-VitePress-CLI",
  description:
    "A lightweight CLI for VitePress project, and supports bilingual template selection.",
  head: [["link", { rel: "icon", href: "/_assets/img/logo.png" }]],

  themeConfig: {
    repo: "YoungX99/byte-vitepress-cli",
    editLinks: true, //编辑按钮
    editLinkText: "在 GitHub 上编辑此页",
    locales: {
      //中文
      "/": {
        lang: "zh-CN",
        // 编辑链接文字
        editLinkText: "在 GitHub 上编辑此页",
        // 更新时间文字
        lastUpdated: "最后更新于",
        // 多语言下拉菜单的标题
        selectText: "选择语言",
        // 该语言在下拉菜单中的标签
        label: "简体中文",
        nav: getNavBar(Language = ""),
        sidebar: {
          "/category/": getCategorySidebar(Language = ""),
        },
      },
      //English
      "/en/": {
        lang: "en-US",
        // 编辑链接文字
        editLinkText: "Edit this page on GitHub",
        // 更新时间文字
        lastUpdated: "Last Updated",
        // 多语言下拉菜单的标题
        selectText: "Language",
        // 该语言在下拉菜单中的标签
        label: "English",
        nav: getNavBar(),
        sidebar: {
          "/en/category/": getCategorySidebar(),
        },
      },
    },
    // 文档搜索插件
    // algolia: {
    //   apiKey: 'your_api_key',
    //   indexName: 'index_name'
    // }
    // 广告推送插件
    // carbonAds: {
    //   carbon: 'your-carbon-key',
    //   custom: 'your-carbon-custom',
    //   placement: 'your-carbon-placement'
    // }
  },
};

function getCategorySidebar(Language = "en/") {
  let basePath = `/${Language}category`;
  return [
    {
      children: [
        {
          text: Language ? "Category" : "目录",
          link: `${basePath}/`,
        },
        {
          text: Language ? "Article-1" : "文章1",
          link: `${basePath}/article-1`,
        },
        {
          text: Language ? "Article-2" : "文章2",
          link: `${basePath}/article-2`,
        },
      ],
    },
  ];
}
function getNavBar(Language = "en/") {
  return [
    // Nav 1
    {
      text: Language ? "Home" : "首页",
      link: Language ? "/en/" : "/",
    },
    // Nav 2
    {
      text: Language ? "Category" : "目录",
      link: `/${Language}category/`,
    },
  ];
}
