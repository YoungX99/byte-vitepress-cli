---
home: true
heroImage: /_assets/img/logo.png
heroAlt: Logo image
heroText: VitePress-脚手架
tagline: 一个轻量级的VitePress脚手架，支持约定路由生成。
actionText: 快速上手
actionLink: /category/
features:
- title: 简易至上
  details: 简单的命令配置让你能更加专注于你的文章写作。
- title: Vue生态支持
  details: 体验Markdown文件中插入你的Vue组件。
- title: 性能优异
  details: VitePress 为每个页面生成预呈现的静态HTML，并在加载页面后作为SPA运行。
footer: MIT Licensed | Copyright © 2019-present Evan You
---