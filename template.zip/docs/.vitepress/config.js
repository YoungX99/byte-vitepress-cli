module.exports = {
  title: "Byte-VitePress-CLI",
  description:
    "A lightweight CLI for VitePress project, and supports bilingual template selection.",
  head: [["link", { rel: "icon", href: "/_assets/img/logo.png" }]],
  themeConfig: {
    nav: getNavBar(),
    sidebar: {
      "/about/": [
        {
          children: [
            { text: "文件名即显示名", link: "/about/文件名即显示名-2" },
            { text: "测试", link: "/about/测试-11" },
          ],
        },
      ],
      "/category/": [
        {
          children: [
            { text: "约定路由", link: "/category/约定路由-1" },
            { text: "测试", link: "/category/测试-2" },
            { text: "低优先级", link: "/category/低优先级-11" },
          ],
        },
      ],
    },
    lastUpdated: "最后更新于",
    repo: "YoungX99/byte-vitepress-cli",
    editLinks: true, //编辑按钮
  },
};

function getNavBar() {
  return [
    // Nav 1
    {
      text: "Home",
      link: "/",
    },
    // Nav 2
    {
      text: "Category",
      link: "/category/约定路由-1",
    },
    {
      text: "About",
      link: "/about/文件名即显示名-2",
    },
  ];
}
